import { Transaction } from '..'

describe('ExampleComponent', () => {
  it('is truthy', () => {
    expect(Transaction).toBeTruthy();
  });
});
