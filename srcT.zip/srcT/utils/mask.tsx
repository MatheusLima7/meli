import React from "react";
import NumberFormat from 'react-number-format';


const currencyMask: (value: string | number) => JSX.Element = (value: string | number) => (
  <NumberFormat
    thousandSeparator='.'
    decimalSeparator=','
    displayType='text'
    fixedDecimalScale
    decimalScale={6}
    value={value}
    prefix='R$ '
  />
);

export const MASKS = {
  CURRENCY: currencyMask,
};