export type TLoading = {
  color: string
  size?: number
}

export default TLoading;