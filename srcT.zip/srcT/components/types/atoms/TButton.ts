export type TButton = {
  loading: boolean | undefined,
  onClick: () => void,
  children: string,
  color: string,
}

export default TButton;