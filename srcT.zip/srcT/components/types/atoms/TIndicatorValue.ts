export type TIndicatorValue = {
  color: string | undefined,
  children: string | JSX.Element,
}

export default TIndicatorValue;
