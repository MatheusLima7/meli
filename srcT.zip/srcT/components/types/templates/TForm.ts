import { TIndicators } from '../organisms';

export type TForm = {
  indicators: Array<TIndicators>;
  changeToggle: () => void;
  formActions: JSX.Element;
  disabled: boolean;
  toggle: boolean;
  title: string;
}