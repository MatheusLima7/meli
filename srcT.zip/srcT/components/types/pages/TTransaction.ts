import { TIndicators } from '../organisms'

export type TTransaction = {
  itens: Array<TTransactionItem>
  disabled: boolean
  title: string
  name: string
  id: string
}

export type TTransactionItem = {
  indicators: Array<TIndicators>
  formActions: JSX.Element
  disabled?: boolean
  title: string
}
