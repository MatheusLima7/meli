export type TAccordion = {
  changeToggle: () => void;
  children: JSX.Element;
  disabled: boolean;
  toggle: boolean;
  title: string;
}

export default TAccordion;
