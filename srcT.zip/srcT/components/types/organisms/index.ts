import { TIndicators } from './TIndicatorsSection';
import { TAccordion } from './TAccordion';

export type {
  TIndicators,
  TAccordion,
};