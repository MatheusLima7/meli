export type TIndicatorsSection = {
  indicators: Array<TIndicators>
}

export type TIndicators = {
  mask?: ((value: string | number) => JSX.Element);
  maskType?: 'CURRENCY';
  value?: string | number;
  color?: string;
  label: string;
  id: string;
};

export default TIndicators;
