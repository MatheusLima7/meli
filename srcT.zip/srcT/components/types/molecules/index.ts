import { TIndicatorDisplay } from './TIndicatorDisplay';
import { TInputNumbers } from './TInputNumbers';

export type {
  TIndicatorDisplay,
  TInputNumbers,
};