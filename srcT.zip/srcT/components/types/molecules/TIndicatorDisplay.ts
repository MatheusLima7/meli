export type TIndicatorDisplay= {
  value?: string | number,
  mask?: (value: string | number) => JSX.Element, 
  color?: string,
  label: string,
}

export default TIndicatorDisplay;
