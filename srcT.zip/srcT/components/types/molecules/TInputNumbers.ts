export type TInputNumbers= {
  onChange: (value: number | undefined) => void
  setInputFocus: (state: boolean) => void
  value: number | string | undefined
  handlerBlur?: () => void
  changingForm?: boolean
  errorMessage?: string
  maskProperties?: any
  placeholder: string
  onClick: () => void
  isEnabled: boolean
  error?: boolean
  testid: string
  field: string
  label: string
}

export default TInputNumbers;
