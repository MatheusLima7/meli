import React from 'react';

import { TIndicators } from '../../types/organisms';
import { IndicatorDisplay } from '../../molecules';
import { MASKS } from '../../../utils/mask';

const IndicatorsSection = ({
  indicators,
}: { indicators: Array<TIndicators> }) => (
  <React.Fragment>
    {indicators.map((indicator: TIndicators) => (
      <IndicatorDisplay
        mask={!indicator.maskType || !MASKS[indicator.maskType]
          ? indicator.mask : MASKS[indicator.maskType]
        }
        value={indicator.value}
        label={indicator.label}
        color={indicator.color}
        key={indicator.id}
      />
    ))}
  </React.Fragment>
);

export default IndicatorsSection;
