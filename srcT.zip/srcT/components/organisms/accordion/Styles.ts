import styled from 'styled-components'

export const Wrapper = styled.div`
  width: 100%;
`;
export const Title = styled.div<{ disabled: boolean }>`
  position: relative;
  background: #2e374d;
  height: 2rem;
  line-height: 2rem;
  color: ${({ disabled }) => disabled ? '#161B27' : '#b7cbec'};
  cursor: ${({ disabled }) => disabled ? 'auto' : 'pointer'};
  font-size: 10px;
  font-weight: 700;
  padding: 0 1rem;
  display: flex;
  justify-content: space-between;
  margin-bottom: 3px;
`;
type TDetail = {
  show: boolean
};
export const Detail = styled.div<TDetail>`
  padding: 1rem;
  margin-bottom: 0.5rem;
  display: ${({ show }) => (show ? 'block' : 'none')};
`;
type TIcon = {
  rotateIcon?: boolean
};
export const Icon = styled.div<TIcon>`
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  transform: ${({ rotateIcon }) => (rotateIcon ? ' rotate(180deg)' : ' rotate(0deg)')};
`;
