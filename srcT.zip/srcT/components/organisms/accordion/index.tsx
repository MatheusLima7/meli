import React from 'react';

import {
  Wrapper,
  Detail,
  Title,
  Icon,
} from './Styles';
import { TAccordion } from '../../types/organisms'

const Accordion = ({
  changeToggle,
  disabled,
  children,
  toggle,
  title,
}: TAccordion) => {

  const onClickAccordion = () => {
    if (!disabled) changeToggle()
  };

  return (
    <Wrapper>
      <Title disabled={disabled} onClick={onClickAccordion}>
        {title}
        <Icon rotateIcon={!toggle}>
          <svg
            width='12'
            height='8'
            viewBox='0 0 12 8'
            fill='none'
            xmlns='http://www.w3.org/2000/svg'
          >
            <path
              fillRule='evenodd'
              clipRule='evenodd'
              d='M1.41 7.41016L6 2.83016L10.59 7.41016L12 6.00016L6 0.000156403L0 6.00016L1.41 7.41016Z'
              fill={disabled ? '#161B27' : '#B7CBEC'}
            />
          </svg>
        </Icon>
      </Title>
      <Detail show={toggle}>
        {children}
      </Detail>
    </Wrapper>
  );
}

export default Accordion;
