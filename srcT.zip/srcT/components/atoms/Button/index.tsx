import React from 'react';

import { TButton } from '../../types/atoms'
import { Loading } from '../../atoms';
import { Wrapper } from './Styles';

const Button = ({
  onClick,
  children,
  loading,
  color,
}: TButton) => {

  if (!children) return null;

  return (
    <Wrapper
      color={color}
      onClick={onClick}
      loadingCircular={!!loading}
    >
      {loading ? (
        <Loading size={16} color='#B7CBEC' />
      ) : (
        children
      )}
    </Wrapper>
  );
}

export default Button;
