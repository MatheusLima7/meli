import styled from 'styled-components'

type TButton = {
  loadingCircular: boolean
  color: string
}

export const Wrapper = styled.button<TButton>`
  width: 100%;
  line-height: 2px;
  height: 22px;
  background: ${({ color }) => color };
  cursor: ${({ loadingCircular }) => loadingCircular ? 'auto' : 'pointer'};
  border-radius: 2px;
  outline: none;
  border: none;
  color: #ffffff;
  font-size: 10px;
  margin-top: 10px;
`

export const Actions = styled.div`
  margin-top: 20px;
`

