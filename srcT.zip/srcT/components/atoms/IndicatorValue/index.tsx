import React from 'react';

import { TIndicatorValue } from '../../types/atoms';
import { Wrapper } from './Styles';

const IndicatorValue = ({ children, color }: TIndicatorValue) => (
  <Wrapper color={color}>{children}</Wrapper>
);

export default IndicatorValue;
