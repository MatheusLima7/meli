import styled from 'styled-components'

export const Wrapper = styled.span<{ color: string | undefined }>`
  color: ${({ color }) => color || '#fbc105'};
  font-weight: 400;
`;

export default Wrapper;
