import styled from 'styled-components'

type TWapper = {
    color: string
    size: number
}

export const Wrapper = styled.div<TWapper>`
    max-width: ${({ size }) => `${size}px`};
    background-color: transparent;
    align-items: center;
    display: flex;
    margin: auto;
    height:100%;
    width: 100%;

    .profile-main-loader .loader:before {
        content: '';
        display: block;
    }

    .circular-loader {
        animation: rotate 2s linear infinite;
        height: 100%;
        width: 100%;
    }

    .loader-path {
        stroke-dasharray: 150,200;
        stroke-dashoffset: -10;
        animation: dash 1.5s ease-in-out infinite, color 6s ease-in-out infinite;
        stroke-linecap: round;
    }

    @keyframes rotate {
        100% {
            -webkit-transform: rotate(360deg);
                    transform: rotate(360deg);
        }
    }

    @keyframes dash {
        0% {
            stroke-dasharray: 1,200;
            stroke-dashoffset: 0;
        }
        50% {
            stroke-dasharray: 89,200;
            stroke-dashoffset: -35;
        }
        100% {
            stroke-dasharray: 89,200;
            stroke-dashoffset: -124;
        }
    }

    @keyframes color {
        0% { stroke: ${({ color }) => color}; }
        40% { stroke: ${({ color }) => color}; }
        66% { stroke: ${({ color }) => color}; }
        80% { stroke: ${({ color }) => color}; }
        90% { stroke: ${({ color }) => color}; }
    }
`
