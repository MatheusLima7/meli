import styled from 'styled-components'

export const Wrapper = styled.div`
  background: #262d3f;
  height: 100%;
`

export const Title = styled.div`
  color: #b7cbec;
  text-transform: uppercase;
  font-size: 0.625rem;
  font-weight: 400;
  margin-bottom: 1rem;
`

export const Code = styled.div`
  font-size: 12px;
  line-height: 18px;
  color: #ffffff;
  font-weight: 700;
`

export const Name = styled.div`
  font-size: 12px;
  line-height: 18px;
  color: #ffffff;
  font-weight: 400;
  margin-bottom: 1.5rem;
`

export const Info = styled.div`
  padding: 0 1rem;
`
