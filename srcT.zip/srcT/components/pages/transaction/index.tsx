import React, { useState, useEffect } from 'react'

import { TTransaction, TTransactionItem } from '../../types/pages'
import { Wrapper, Title, Code, Name, Info } from './Styles'
import { Form } from '../../templates'

const Transaction: React.FC<any> = ({
  itens = [],
  title,
  name,
  id
}: TTransaction) => {
  const [toggles, setToggles] = useState<Array<boolean>>([])

  useEffect(() => {
    setToggles(itens.map(() => false))
  }, [itens])

  const changeToggle = (index: number, value: boolean) => {
    const newToggles = toggles.map(() => false)
    newToggles[index] = !value
    setToggles(newToggles)
  }

  return (
    <Wrapper>
      <Info>
        <Title>{title}</Title>
        <Code>{id}</Code>
        <Name>{name}</Name>
      </Info>
      {itens.map((transaction: TTransactionItem, index: number) => (
        <Form
          changeToggle={() => changeToggle(index, toggles[index])}
          formActions={transaction.formActions}
          indicators={transaction.indicators}
          key={`transaction-${id}-${index}`}
          disabled={!!transaction.disabled}
          title={transaction.title}
          toggle={toggles[index]}
        />
      ))}
    </Wrapper>
  )
}

export default Transaction
