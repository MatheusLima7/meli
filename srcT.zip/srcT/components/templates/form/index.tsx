import React from 'react'

import { IndicatorsSection, Accordion } from '../../organisms'
import { TForm } from '../../types/templates'
import { Wrapper } from './Styles'

const Form = ({
  changeToggle,
  formActions,
  indicators,
  disabled,
  toggle,
  title
}: TForm) => {
  return (
    <Wrapper>
      <Accordion
        changeToggle={changeToggle}
        disabled={disabled}
        toggle={toggle}
        title={title}
      >
        <React.Fragment>
          <IndicatorsSection indicators={indicators} />
          {formActions}
        </React.Fragment>
      </Accordion>
    </Wrapper>
  )
}

export default Form
