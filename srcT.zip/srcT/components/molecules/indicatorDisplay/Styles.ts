import styled from 'styled-components'

export const Wrapper = styled.div`
  font-weight: 700;
  font-size: 12px;
  color: #ffffff;
  line-height: 20px;
`;

export default Wrapper;
