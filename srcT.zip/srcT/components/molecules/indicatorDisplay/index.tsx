import React from 'react';

import { TIndicatorDisplay } from '../../types/molecules';
import { IndicatorValue } from '../../atoms';
import { Wrapper } from './Styles';

const IndicatorDisplay = ({
  value,
  label,
  color,
  mask,
}: TIndicatorDisplay) => {
  if (!value) {
    return (<Wrapper>{label}</Wrapper>);
  }

  return (
    <Wrapper>{label}: <IndicatorValue color={color}>
      {mask ? mask(value) : value.toString()}
    </IndicatorValue></Wrapper>
  );
};

export default IndicatorDisplay;
