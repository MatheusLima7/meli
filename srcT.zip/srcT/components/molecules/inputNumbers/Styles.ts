import styled from 'styled-components'

type TInputProps = {
  changingForm?: boolean;
  isEmptyValue: boolean;
  isEnabled?: boolean;
  error?: boolean;
}

export const InputComponent = styled.input<TInputProps>`
  display: ${({ isEnabled }) => (isEnabled ? 'flex' : 'none')};
  opacity: ${({ isEnabled }) => (isEnabled ? '1' : '0')};
  padding: 0px 0.4rem;
  background-color: ${({ changingForm, isEmptyValue }) => (
    changingForm && !isEmptyValue ? '#FFF' : '#2e374c'
  )};
  font-size: 0.75rem;
  line-height: 27px;
  color: ${({ isEmptyValue, changingForm }) => {
    if (changingForm && !isEmptyValue) return '#10121A'
    return isEmptyValue ? '#6d7d98' : '#FFFFFF'
  }};
  width: ${({ isEnabled }) => (isEnabled ? '100%' : '0')};
  box-sizing: border-box;
  outline: none;
  border: none;
  transition: background-color 0.4s ease-in-out,
    opacity 1s ease-in-out,
    width 1s ease-in-out;
  width: 100%;
  height: 32px;
  line-height: 32px;
  border: ${({ error }) => (error ? '1px solid #FB6663' : 'none')};
  &::placeholder {
    color: #6d7d98;
  }
`
export const Label = styled.span`
  color: #ffffff;
  font-size: 12px;
  width: 1.625rem;
  margin-top: 0.5rem;
  margin-right: 1ch;
`

export const ErrorLabel = styled.span<{ error: boolean }>`
  color: ${({ error }) => error ? '#FB6663' : '#ffffff'};
  font-size: 12px;
  font-size: ${({ error }) => error ? '12px' : '9px'};
  margin-top: 0.5rem;
  margin-bottom: 0.2rem;
`

export const Row = styled.div`
    display: flex;
    flex-direction: row;
    width: 100%;
`;

export const Column = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

export const Wrapper = styled.div`
  flex-direction: column;
  margin: 0.4rem 0;
  display: flex;
`
