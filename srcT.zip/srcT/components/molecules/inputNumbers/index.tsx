import React, { useState } from 'react'
import NumberFormat from 'react-number-format'

import { TInputNumbers } from '../../types/molecules'
import {
  InputComponent,
  ErrorLabel,
  Wrapper,
  Column,
  Label,
  Row
} from './Styles'

const CustomInput = (props: any) => <InputComponent {...props} />

const formatCurrencyByEnd = (
  value: string,
  minimumFractionDigits: number
): string => {
  if (!Number(value)) return ''

  const amount = new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits
  }).format(parseFloat(value) / 100)

  return `${amount}`
}

const Input = ({
  maskProperties = {},
  setInputFocus,
  changingForm,
  errorMessage,
  placeholder,
  handlerBlur,
  isEnabled,
  onChange,
  onClick,
  value,
  error,
  label,
  testid
}: TInputNumbers) => {
  const [focus, setFocus] = useState<boolean>(false)

  let proFractionalNumber = {}
  if (maskProperties.decimalScale) {
    proFractionalNumber = {
      format: (value: string) =>
        formatCurrencyByEnd(value, maskProperties.decimalScale)
    }
  }

  const onValueChange = (values: any) => {
    if (maskProperties.decimalScale)
      return (
        focus &&
        onChange(
          Number((values.floatValue / 100).toFixed(maskProperties.decimalScale))
        )
      )
    return focus && onChange(values.floatValue)
  }

  const onFocus = () => {
    setFocus(true)
    setInputFocus(true)
  }

  const onBlur = () => {
    setFocus(false)
    setInputFocus(false)
    handlerBlur && handlerBlur()
  }

  return (
    <Wrapper>
      <Row>
        <Label>{label}</Label>
        <Column data-testid={testid}>
          <NumberFormat
            {...maskProperties}
            {...proFractionalNumber}
            fixedDecimalScale
            thousandSeparator='.'
            decimalSeparator=','
            inputMode='numeric'
            displayType='input'
            allowNegative={false}
            placeholder={placeholder}
            isEnabled={isEnabled}
            onClick={onClick}
            onFocus={onFocus}
            onBlur={onBlur}
            changingForm={changingForm}
            type='text'
            error={error}
            value={value}
            onValueChange={onValueChange}
            isEmptyValue={!value}
            customInput={CustomInput}
          />
          {errorMessage && (
            <ErrorLabel error={!!error}>{errorMessage}</ErrorLabel>
          )}
        </Column>
      </Row>
    </Wrapper>
  )
}

export default Input
